class NoMatchingDataError(Exception):
    pass

class UnauthorizedError(Exception):
    pass